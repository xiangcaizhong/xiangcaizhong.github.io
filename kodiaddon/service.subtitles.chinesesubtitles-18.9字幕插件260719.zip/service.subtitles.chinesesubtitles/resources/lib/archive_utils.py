# -*- coding: utf-8 -*-
import os
import urllib
import xbmcvfs
import xbmc

SUBTITLE_EXTS = (".srt", ".sub", ".ssa", ".ass", ".sup", ".vtt")
ARCHIVE_EXTS = (".zip", ".rar", ".7z")

class _NullLogger:
    def log(self, *args, **kwargs):
        pass

def _unpack_zip(real_path, logger):
    import zipfile
    from _gbk_codec import fix_zip_filename
    try:
        with zipfile.ZipFile(real_path, 'r') as zf:
            entries = []
            for info in zf.infolist():
                if info.is_dir():
                    continue
                name = info.filename if (info.flag_bits & 0x800) else fix_zip_filename(info.filename)
                name = os.path.basename(name)
                if name.lower().endswith(SUBTITLE_EXTS):
                    entries.append((name, info))
            if not entries:
                return None, []
            extract_dir = real_path + '_extracted'
            os.makedirs(extract_dir, exist_ok=True)
            result = []
            for name, info in entries:
                with zf.open(info) as src, open(os.path.join(extract_dir, name), 'wb') as dst:
                    dst.write(src.read())
                result.append(name)
            return extract_dir, result
    except Exception as e:
        logger.log("archive_utils", "ZIP extract failed: %s" % e, 2)
        return None, []

def unpack(file_path, logger=None):
    """
    获取归档文件中的字幕列表，或直接返回字幕文件。
    """
    logger = logger or _NullLogger()
    file_path = file_path.replace('\\', '/').rstrip('/')
    
    ext = os.path.splitext(file_path)[1].lower()  # 带点扩展名
    
    # 如果不是归档文件
    if ext not in ARCHIVE_EXTS:
        if ext in SUBTITLE_EXTS:
            logger.log("archive_utils", "Direct subtitle file: %s" % os.path.basename(file_path), 1)
            return os.path.dirname(file_path), [os.path.basename(file_path)]
        else:
            logger.log("archive_utils", "Unsupported file type: %s" % ext, 2)
            return '', []

    # 处理归档
    real_path = xbmc.translatePath(file_path)
    if ext == '.zip':
        return _unpack_zip(real_path, logger)

    vfs_protocol = 'archive' if ext == '.7z' else 'rar'
    archive_url = urllib.quote_plus(real_path)
    vfs_url = "{0}://{1}".format(vfs_protocol, archive_url)
    logger.log("archive_utils", "Unpacking archive: %s" % vfs_url)

    try:
        dirs, files = xbmcvfs.listdir(vfs_url)
        if '__MACOSX' in dirs:
            dirs.remove('__MACOSX')
        target_path = vfs_url
        if not any(f.lower().endswith(SUBTITLE_EXTS) for f in files) and dirs:
            target_path = vfs_url + '/' + dirs[0]
            dirs, files = xbmcvfs.listdir(target_path)
        subtitle_list = [f for f in files if f.lower().endswith(SUBTITLE_EXTS)]
        return target_path, subtitle_list
    except Exception as e:
        logger.log("archive_utils", "Unpack error: %s" % e, 2)
        return '', []