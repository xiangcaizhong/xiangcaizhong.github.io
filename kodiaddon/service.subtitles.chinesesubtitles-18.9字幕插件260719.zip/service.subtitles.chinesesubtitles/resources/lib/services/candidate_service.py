# -*- coding: utf-8 -*-
import xbmc

def _get_zimuku_agent():
    from providers.zimuku.agent import ZimukuAgent
    class NullLogger:
        def log(self, *args, **kwargs):
            pass
    class NullUnpacker:
        def unpack(self, path):
            return path, []
    return ZimukuAgent(None, None, NullLogger(), NullUnpacker())

def _search_douban(title, db_year, db_season, logger=None):
    candidates = []
    try:
        import douban_agent
        agent = douban_agent.get_agent()
        candidates = agent.search(title=title, year=db_year, season=db_season) or []
        if logger:
            logger.log("CandidateService", "Douban search returned %d candidates" % len(candidates), 1)
        if not candidates and db_year:
            if logger:
                logger.log("CandidateService", "No results with year %s, retrying without year..." % db_year, 1)
            candidates = agent.search(title=title, year=None, season=db_season) or []
            if logger:
                logger.log("CandidateService", "Retry without year returned %d candidates" % len(candidates), 1)
    except Exception as e:
        if logger:
            logger.log("CandidateService", "Douban search failed: %s" % e, 2)
    return candidates

def _select_candidate(candidates, logger=None):
    if not candidates:
        return None
    try:
        import xbmcgui
        labels = []
        for res in candidates:
            # 强制所有字符串为 unicode
            title = res.get('title', u'未知')
            if isinstance(title, str):
                title = title.decode('utf-8', errors='ignore')
            year = res.get('year', u'????')
            if isinstance(year, str):
                year = year.decode('utf-8', errors='ignore')
            type_cn = u'剧集' if res.get('type') == 'tv' else u'电影'
            source = res.get('source', u'豆瓣')
            sid = res.get('id', u'')
            display = u"[%s][%s][%s] %s" % (source, type_cn, year, title)
            if sid:
                display += u" (ID:%s)" % sid
            labels.append(display)
        sel = xbmcgui.Dialog().select(u"请选择正确的影片 (ESC取消)", labels)
        if sel == -1 or sel >= len(candidates):
            return None
        return candidates[sel]
    except Exception as e:
        if logger:
            logger.log("CandidateService", "Selection dialog failed: %s" % e, 2)
        return candidates[0] if candidates else None

def get_candidate(title, items, logger=None):
    is_tv = bool(items.get("tvshow"))
    db_year = items.get("year")
    db_season = items.get("season") if is_tv else None

    if logger:
        logger.log("CandidateService", "Searching for title='%s', year='%s', is_tv=%s" % (title, db_year, is_tv), 1)

    candidates = _search_douban(title, db_year, db_season, logger)

    if not candidates:
        if logger:
            logger.log("CandidateService", "Douban returned no candidates, trying Zimuku...", 1)
        zimuku = _get_zimuku_agent()
        try:
            zimuku_candidates = zimuku.search_candidates(title, db_year, is_tv=is_tv)
            if zimuku_candidates:
                candidates = zimuku_candidates
                if logger:
                    logger.log("CandidateService", "Zimuku returned %d candidates" % len(zimuku_candidates), 1)
        except Exception as e:
            if logger:
                logger.log("CandidateService", "Zimuku search failed: %s" % e, 2)

    if not candidates:
        try:
            import xbmcgui
            xbmcgui.Dialog().ok(u"提示", u"未找到任何影片候选，请检查网络或手动输入搜索词。")
        except:
            pass
        return None

    target_type = "tv" if is_tv else "movie"
    try:
        target_year = int(db_year) if db_year else None
    except:
        target_year = None

    def type_key(res):
        return 0 if res.get("type") == target_type else 1

    def year_key(res):
        if target_year is None:
            return 0
        try:
            return abs(int(res.get("year")) - target_year)
        except:
            return 9999

    grouped = {}
    for res in candidates:
        src = res.get("source") or "douban"
        grouped.setdefault(src, []).append(res)

    sorted_candidates = []
    for src in ["douban", "zimuku"]:
        if src in grouped:
            sorted_candidates.extend(sorted(grouped[src], key=lambda r: (type_key(r), year_key(r))))
    for src, lst in grouped.items():
        if src not in ["douban", "zimuku"]:
            sorted_candidates.extend(sorted(lst, key=lambda r: (type_key(r), year_key(r))))

    if logger:
        logger.log("CandidateService", "Sorted %d candidates" % len(sorted_candidates), 1)

    selected = _select_candidate(sorted_candidates, logger)
    if not selected:
        if logger:
            logger.log("CandidateService", "User cancelled selection", 1)
        return None

    if selected.get("source") == "zimuku" and not selected.get("id"):
        if logger:
            logger.log("CandidateService", "Fetching Douban ID for zimuku candidate...", 1)
        zimuku = _get_zimuku_agent()
        selected["id"] = zimuku.get_douban_id_from_subs(selected.get("zimuku_subs_url"))
        if not selected.get("type"):
            selected["type"] = "tv" if is_tv else "movie"

    if logger:
        logger.log("CandidateService", "最终选中的候选: %s" % repr(selected), 1)

    return selected