# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import re
from bs4 import BeautifulSoup
from ..base import BaseAgent
from ..common import get_filename_from_cd, save_and_unpack

def _to_unicode(text):
    if text is None:
        return u''
    if isinstance(text, unicode):
        return text
    if isinstance(text, str):
        try:
            return text.decode('utf-8')
        except UnicodeDecodeError:
            return text.decode('gbk', errors='ignore')
    return unicode(text)

FORMATS = ["ASS", "SRT", "SSA", "SUB", "SUP", "VTT"]

class SubHDAgent(BaseAgent):
    def __init__(self, base_url, dl_location, logger, unpacker):
        super(SubHDAgent, self).__init__(base_url, "https://subhdtw.com", dl_location, logger, unpacker)

    def _extract_tags(self, spans):
        tags = {'source': [], 'lang': [], 'fmt': [], 'bilingual': False}
        for span in spans:
            classes = span.get('class', [])
            text = _to_unicode(span.get_text().strip())
            if 'rounded' in classes and 'text-white' in classes:
                src_map = {'转载精修': 'reprint', '官方字幕': 'official', '原创翻译': 'original', '机器翻译': 'machine', 'AI翻润色': 'ai'}
                for k, v in src_map.items():
                    if k in text:
                        tags['source'].append(v)
                        break
            if 'fw-bold' in classes:
                if '简体' in text: tags['lang'].append('chs')
                if '繁体' in text: tags['lang'].append('cht')
                if '英语' in text: tags['lang'].append('eng')
                if '双语' in text: tags['bilingual'] = True
            if 'text-secondary' in classes:
                for fmt in FORMATS:
                    if fmt in text.upper():
                        tags['fmt'].append(fmt.lower())
                        break
        return tags

    def _parse_subtitles(self, content, target_episode=None):
        soup = BeautifulSoup(content, 'html.parser')
        container = soup.select_one('div.bg-white.shadow-sm.rounded-3.mb-5')
        if not container: return []
        results = []
        category = "general"
        for child in container.children:
            if child.name != 'div': continue
            classes = child.get('class', [])
            if 'bg-light' in classes:
                text = _to_unicode(child.get_text().strip())
                if "合集" in text:
                    category = "collection"
                elif "第" in text and "集" in text:
                    match = re.search(r'第\s*(\d+)\s*集', text)
                    category = int(match.group(1)) if match else "general"
                else:
                    category = "general"
            elif 'row' in classes:
                is_match, is_coll = False, False
                if target_episode:
                    t_ep = int(target_episode) if str(target_episode).isdigit() else target_episode
                    if category == t_ep or str(category) == str(target_episode): is_match = True
                    elif category == "collection": is_match, is_coll = True, True
                else:
                    is_match = True
                    is_coll = category == "collection"
                if not is_match: continue
                link = child.select_one('a.link-dark')
                if not link: continue
                href = link.get('href', '')
                if not href.startswith('/a/'): continue
                tags = self._extract_tags(child.find_all('span'))
                if is_coll: tags['collection'] = True
                zu = child.select_one('a[href^="/zu/"]') or child.select_one('a[href^="/u/"]')
                tags['fansub'] = _to_unicode(zu.get_text().strip()) if zu else ""
                results.append(self._build_result(_to_unicode(link.get_text().strip()), self.BASE_URL + href, tags))
        return results

    def _resolve_imdb(self, imdb_id):
        search_url = "{0}/search/{1}".format(self.BASE_URL, imdb_id)
        content = self.get_page(search_url)
        if not content:
            return None
        soup = BeautifulSoup(content, 'html.parser')
        container = soup.select_one('div.col-lg-9')
        if not container:
            return None
        link = container.select_one('a[href^="/d/"]')
        if link:
            m = re.search(r'/d/(\d+)', link['href'])
            if m:
                return m.group(1)
        return None

    def search(self, items, candidate=None):
        if not candidate or not candidate.get('id'): return []
        if candidate.get('source') == 'imdb':
            resolved_id = self._resolve_imdb(candidate['id'])
            if not resolved_id:
                self.log("SubHD: IMDB %s not found" % candidate['id'], 2)
                return []
            candidate = dict(candidate, **{'id': resolved_id})
        url = "{0}/d/{1}".format(self.BASE_URL, candidate.get('id'))
        content = self.get_page(url)
        if not content: return []
        episode = items.get('episode') if items.get('tvshow') else None
        results = self._parse_subtitles(content, episode)
        prod = "剧集" if candidate.get('type') == 'tv' else "电影"
        for r in results:
            r['tags']['production'] = prod
        return results

    def _get_sid_from_page(self, content):
        soup = BeautifulSoup(content, 'html.parser')
        download_btn = soup.select_one('button.subtitle-prepare-download[data-sid]')
        if download_btn:
            sid = download_btn.get('data-sid')
            if sid:
                self.log("Found sid from button: %s" % sid)
                return sid
        down_link = soup.find('a', href=re.compile(r'/down/'))
        if down_link:
            href = down_link.get('href', '')
            sid = href.split('/')[-1]
            if sid:
                self.log("Found sid from /down/ link: %s" % sid)
                return sid
        down_btn = soup.find('a', class_='down')
        if down_btn:
            href = down_btn.get('href', '')
            if '/down/' in href:
                sid = href.split('/')[-1]
                if sid:
                    self.log("Found sid from .down link: %s" % sid)
                    return sid
        self.log("Could not find sid in page", 2)
        return None

    def download(self, url):
        content = self.get_page(url)
        if not content:
            return [], [], []
        sid = self._get_sid_from_page(content)
        if not sid:
            if '/a/' in url:
                sid = url.split('/a/')[-1].split('?')[0].split('#')[0]
                self.log("Extracted sid from URL: %s" % sid)
            else:
                return [], [], []
        api_url = self.BASE_URL + "/api/sub/down"
        max_retries = 2
        for attempt in range(max_retries + 1):
            try:
                payload = {"sid": sid, "cap": ""}
                self.log("Calling API: %s with sid=%s (attempt %d)" % (api_url, sid, attempt+1))
                res = self.session.post(api_url, json=payload, headers={'Referer': url}, timeout=10)
                if res.status_code != 200:
                    self.log("API returned status %d" % res.status_code, 2)
                    if attempt < max_retries:
                        continue
                    return [], [], []
                data = res.json()
                self.log("API response: %s" % data)
                if data.get('pass') == False:
                    svg = data.get('msg')
                    if svg:
                        from .captcha import SubHDSolver
                        code = SubHDSolver().solve(svg)
                        self.log("Captcha solved: %s" % code)
                        payload["cap"] = code
                        # 重试提交验证码
                        res = self.session.post(api_url, json=payload, headers={'Referer': url}, timeout=10)
                        if res.status_code != 200:
                            if attempt < max_retries:
                                continue
                            return [], [], []
                        data = res.json()
                        if not data.get('success'):
                            self.log("Captcha verification failed, attempt %d" % (attempt+1), 2)
                            if attempt < max_retries:
                                # 重新获取页面以刷新sid
                                content = self.get_page(url)
                                if content:
                                    sid = self._get_sid_from_page(content)
                                    if not sid and '/a/' in url:
                                        sid = url.split('/a/')[-1].split('?')[0].split('#')[0]
                                continue
                            return [], [], []
                if not data.get('success'):
                    self.log("Download API returned success=false", 2)
                    if attempt < max_retries:
                        continue
                    return [], [], []
                file_url = data.get('url')
                if not file_url:
                    self.log("No file_url in API response", 2)
                    if attempt < max_retries:
                        continue
                    return [], [], []
                if not file_url.startswith('http'):
                    file_url = self.BASE_URL + file_url
                self.log("Downloading from: %s" % file_url)
                file_res = self.session.get(file_url, headers={'Referer': url}, timeout=30)
                if file_res.status_code != 200:
                    self.log("File download failed: %d" % file_res.status_code, 2)
                    if attempt < max_retries:
                        continue
                    return [], [], []
                filename = get_filename_from_cd(
                    file_res.headers.get("Content-Disposition"),
                    url=file_res.url or file_url,
                    default="subtitle.zip"
                )
                if isinstance(filename, str):
                    try:
                        filename = filename.decode('utf-8')
                    except UnicodeDecodeError:
                        filename = filename.decode('gbk', errors='ignore')
                return save_and_unpack(self.DOWNLOAD_LOCATION, self.unpacker, filename, file_res.content)
            except Exception as e:
                self.log("Download exception attempt %d: %s" % (attempt+1, _to_unicode(e)), 2)
                if attempt < max_retries:
                    continue
                return [], [], []
        return [], [], []