# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import os
import re
import urllib
import urlparse
from bs4 import BeautifulSoup
from .captcha import ZimukuSolver
from ..base import BaseAgent
from ..common import get_filename_from_cd, save_and_unpack, SUBTITLE_EXTS, ARCHIVE_EXTS

def _to_unicode(text):
    if text is None:
        return u''
    if isinstance(text, unicode):
        return text
    if isinstance(text, str):
        try:
            return text.decode('utf-8')
        except UnicodeDecodeError:
            return text.decode('gbk', errors='ignore')
    return unicode(text)

class ZimukuAgent(BaseAgent):
    FILE_MIN_SIZE = 1024

    def __init__(self, base_url, dl_location, logger, unpacker):
        super(ZimukuAgent, self).__init__(base_url, "https://zimuku.org", dl_location, logger, unpacker)
        import requests
        self.session.mount('https://', requests.adapters.HTTPAdapter(max_retries=3))

    MAX_CAPTCHA_RETRIES = 3

    def get_page(self, url, referer=None):
        if url and not url.startswith('http'):
            url = urlparse.urljoin(self.BASE_URL, url)
        headers = {'Referer': referer} if referer else {}
        try:
            for attempt in range(self.MAX_CAPTCHA_RETRIES + 1):
                resp = self.session.get(url, headers=headers, timeout=10)
                if resp is None:
                    break
                if resp.status_code == 200 and b'class="verifyimg"' not in resp.content:
                    return resp.content
                if resp.content and b'class="verifyimg"' in resp.content:
                    if attempt < self.MAX_CAPTCHA_RETRIES:
                        self._solve_captcha(url, resp.content, headers)
                        continue
                    else:
                        self.log("Captcha failed after %d attempts" % self.MAX_CAPTCHA_RETRIES, 2)
                        return None
                if resp.status_code != 200:
                    break
            status = resp.status_code if resp is not None else 'N/A'
            self.log("Failed to get page %s, status: %s" % (url, status), 2)
            return None
        except Exception as e:
            self.log("Exception getting page %s: %s" % (url, _to_unicode(e)), 2)
            return None

    def _solve_captcha(self, url, page_content, headers=None):
        try:
            soup = BeautifulSoup(page_content, 'html.parser')
            img = soup.find(attrs={'class': 'verifyimg'})
            if not img: return
            img_src = img.get('src', '')
            if 'data:image/bmp;base64,' not in img_src: return
            b64 = img_src.split('data:image/bmp;base64,', 1)[1]
            text = ZimukuSolver(b64).recognize()
            hex_str = ''.join('%x' % ord(c) for c in text)
            sep = '&' if '?' in url else '?'
            verify_url = "{0}{1}security_verify_img={2}".format(url, sep, hex_str)
            self.session.get(verify_url, headers=headers)
        except Exception as e:
            self.log("Captcha error: %s" % _to_unicode(e), 2)

    def search_candidates(self, title, year=None, is_tv=False):
        if not title: return []
        query = title
        search_url = "{0}/search?q={1}&chost=zimuku.org".format(self.BASE_URL, urllib.quote(query.encode('utf-8')))
        data = self.get_page(search_url)
        if not data: return []
        soup = BeautifulSoup(data, "html.parser")
        results, seen = [], set()
        for item in soup.select('div.item'):
            link = item.select_one('div.title p.tt a')
            if not link: continue
            href = link.get("href", "")
            if not re.search(r"/subs/\d+\.html", href): continue
            subs_url = urlparse.urljoin(self.BASE_URL, href)
            if subs_url in seen: continue
            seen.add(subs_url)
            label = link.get_text(strip=True)
            if label:
                results.append({"label": "[备用] %s" % _to_unicode(label), "title": _to_unicode(label), "type": "tv" if is_tv else "movie", "source": "zimuku", "zimuku_subs_url": subs_url})
        return results

    def get_douban_id_from_subs(self, subs_url):
        if not subs_url: return None
        data = self.get_page(subs_url)
        if not data: return None
        soup = BeautifulSoup(data, "html.parser")
        link = soup.find("a", href=re.compile(r"movie\.douban\.com/subject/\d+/"))
        if not link:
            img = soup.find("img", src=re.compile(r"douban_(big|icon)\.png"))
            if img and img.parent.name == "a": link = img.parent
        if link:
            match = re.search(r"subject/(\d+)/", link.get("href", ""))
            return match.group(1) if match else None
        return None

    def _extract_sub_info(self, sub, production=None, collection=False):
        link = urlparse.urljoin(self.BASE_URL, sub.a.get('href'))
        name = _to_unicode(sub.a.text)
        langs = []
        try:
            td = sub.find("td", class_="tac lang")
            if td:
                for img in td.find_all("img"):
                    title = img.get('title', '')
                    if title:
                        langs.append(_to_unicode(title).rstrip('字幕'))
        except Exception as e:
            self.log("Failed to parse langs: %s" % _to_unicode(e), 2)
        rating = "0"
        try:
            star = sub.find("i", class_="rating-star")
            if star:
                star_str = _to_unicode(star)
                idx = star_str.find("allstar")
                if idx >= 0 and idx + 7 < len(star_str) and star_str[idx + 7].isdigit():
                    rating = star_str[idx + 7]
        except Exception as e:
            self.log("Failed to parse rating: %s" % _to_unicode(e), 2)
        tags = {"source": [], "lang": [], "fmt": [], "bilingual": False, "production": _to_unicode(production or ""), "collection": bool(collection)}
        fmt_span = sub.find("span", class_="label-info")
        if fmt_span:
            fmt_text = _to_unicode(fmt_span.text.strip()).lower()
            tags["fmt"] = [f.strip() for f in fmt_text.split('/')] if '/' in fmt_text else [fmt_text]
        fansub_link = sub.select_one('a[href^="/t/"]')
        if fansub_link:
            tags["fansub"] = _to_unicode(fansub_link.text.strip())
        else:
            danger = sub.find("span", class_="label-danger")
            if danger:
                tags["fansub"] = _to_unicode(danger.text.strip())
        if '简体中文' in langs: tags["lang"].append("chs")
        if '繁體中文' in langs: tags["lang"].append("cht")
        if 'English' in langs: tags["lang"].append("eng")
        if '双语' in langs: tags["bilingual"] = True
        return self._build_result(name, link, tags)

    def _build_episode_filter(self, season, episode):
        if not (season and episode and str(season).isdigit() and str(episode).isdigit()):
            return lambda name: (True, False)
        ep = int(episode)
        tokens = ["S{0:02d}E{1:02d}".format(int(season), ep), "E{0:02d}".format(ep), "EP{0:02d}".format(ep), "E{0}".format(ep), "EP{0}".format(ep), "第{0}集".format(ep)]
        tag_re = re.compile(r'(S\d{1,2}\s*(E|EP)\d{1,3})|(\bEP?\d{1,3}\b)|(第\s*\d+\s*集)')
        ep_re = re.compile(r'(?<!\d)({0})(?!\d)'.format("|".join(re.escape(t) for t in tokens)), re.IGNORECASE)
        def fn(name):
            upper = name.upper()
            has_tag = tag_re.search(upper) is not None
            matches = ep_re.search(upper) is not None
            return (not has_tag or matches, not has_tag)
        return fn

    def search(self, items, candidate=None):
        if not candidate: return []
        subs_url = candidate.get('zimuku_subs_url')
        production = "剧集" if candidate.get('type') == 'tv' or items.get('tvshow') else "电影"
        if not subs_url:
            search_id = candidate.get('id')
            if not search_id: return []
            search_url = "{0}/search?q={1}&chost=zimuku.org".format(self.BASE_URL, urllib.quote(str(search_id).encode('utf-8')))
            data = self.get_page(search_url)
            if not data: return []
            soup = BeautifulSoup(data, 'html.parser')
            link = soup.find('a', href=re.compile(r'/subs/\d+\.html'))
            if not link: return []
            subs_url = urlparse.urljoin(self.BASE_URL, link.get('href'))
        data = self.get_page(subs_url)
        if not data: return []
        box = BeautifulSoup(data, 'html.parser').select_one("div.subs.box.clearfix")
        if not box or not box.tbody: return []
        subs = box.tbody.find_all("tr")
        ep_filter = self._build_episode_filter(items.get('season'), items.get('episode'))
        results = []
        for sub in reversed(subs):
            name = _to_unicode(sub.a.text)
            include, is_coll = ep_filter(name)
            if include:
                results.append(self._extract_sub_info(sub, production, is_coll))
        return results

    def download(self, url):
        try:
            data = self.get_page(url)
            if not data: return [], [], []
            soup = BeautifulSoup(data, 'html.parser')
            dl_link = soup.find("li", class_="dlsub")
            if not dl_link or not dl_link.a: return [], [], []
            # 确保 dl_url 是 Unicode
            dl_url = _to_unicode(dl_link.a.get('href'))
            dl_url = urlparse.urljoin(self.BASE_URL, dl_url)
            data = self.get_page(dl_url)
            if not data: return [], [], []
            soup = BeautifulSoup(data, 'html.parser')
            links = soup.find("div", class_="clearfix")
            if not links: return [], [], []
            links = links.find_all('a')
            referer = dl_url
        except Exception as e:
            self.log("Download page parse error: %s" % _to_unicode(e), 2)
            return [], [], []
        
        filename, file_data = None, None
        for link in links:
            href = link.get('href')
            if not href: continue
            # 将 href 转换为 Unicode
            href = _to_unicode(href)
            file_url = urlparse.urljoin(self.BASE_URL, href)
            try:
                resp = self.session.get(file_url, headers={'Referer': referer}, timeout=10)
                if resp is None or resp.status_code != 200: continue
                # 获取文件名（确保unicode）
                raw_filename = get_filename_from_cd(resp.headers.get('Content-Disposition'), url=file_url)
                if not raw_filename:
                    # 从URL提取
                    parsed_url = urlparse.urlparse(file_url)
                    raw_filename = os.path.basename(parsed_url.path)
                if raw_filename:
                    if isinstance(raw_filename, str):
                        try:
                            raw_filename = raw_filename.decode('utf-8')
                        except UnicodeDecodeError:
                            raw_filename = raw_filename.decode('gbk', errors='ignore')
                if not raw_filename:
                    continue
                file_data = resp.content
                if len(file_data) > self.FILE_MIN_SIZE:
                    filename = raw_filename
                    break
            except Exception as e:
                self.log("Failed to download from %s: %s" % (file_url, _to_unicode(e)), 2)
        
        if not filename or not file_data or len(file_data) <= self.FILE_MIN_SIZE:
            return [], [], []
        
        # 确保文件名是unicode后再操作
        if isinstance(filename, str):
            try:
                filename = filename.decode('utf-8')
            except UnicodeDecodeError:
                filename = filename.decode('gbk', errors='ignore')
        dot = filename.rfind(".")
        if dot != -1:
            filename = filename[:dot] + filename[dot:].lower()
        if filename.endswith(SUBTITLE_EXTS) or filename.endswith(ARCHIVE_EXTS):
            return save_and_unpack(self.DOWNLOAD_LOCATION, self.unpacker, filename, file_data)
        return [], [], []