# -*- coding: utf-8 -*-
# from providers.subhd import SubHDAgent   # 暂时禁用 SubHD（验证码机制导致下载失败）
from providers.zimuku import ZimukuAgent


def build_agents(temp_dir, logger, unpacker):
    return {
        # "subhd": SubHDAgent(None, temp_dir, logger, unpacker),   # 注释掉，使用 Zimuku 代替
        "zimuku": ZimukuAgent(None, temp_dir, logger, unpacker),
    }