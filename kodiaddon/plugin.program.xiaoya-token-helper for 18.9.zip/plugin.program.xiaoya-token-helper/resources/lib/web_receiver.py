# -*- coding: utf-8 -*-
import socket
import urllib
import threading
import BaseHTTPServer
import time
import xbmc
import os
from urlparse import urlparse, parse_qs

# 全局变量
received_token = None
received_folder_id = None
received_open_token = None
server_stop_flag = False

# 文件路径定义
TOKEN_PATH = "/storage/xiaoya/mytoken.txt"
FOLDER_PATH = "/storage/xiaoya/temp_transfer_folder_id.txt"
OPEN_TOKEN_PATH = "/storage/xiaoya/myopentoken.txt"
OPEN_TOKEN_URL_PATH = "/storage/xiaoya/opentoken_url.txt"

def clean_token(content):
    """只保留 ASCII 可打印字符 (32-126)"""
    if content is None:
        return u""
    cleaned = u"".join(c for c in content if 32 <= ord(c) <= 126)
    return cleaned.strip()

def ensure_opentoken_url():
    """确保 opentoken_url.txt 存在且内容正确"""
    current_ip = get_local_ip()
    if current_ip == '无法获取IP，请检查网络':
        current_ip = '192.168.1.xxx'
    open_token_url = u"http://{}:5245/api/oauth/alipan/token".format(current_ip)
    
    try:
        dirpath = os.path.dirname(OPEN_TOKEN_URL_PATH)
        if not os.path.exists(dirpath):
            os.makedirs(dirpath)
        with open(OPEN_TOKEN_URL_PATH, 'w') as f:
            f.write(open_token_url.encode('utf-8'))
            f.write('\n')
        os.chmod(OPEN_TOKEN_URL_PATH, 0644)
        return open_token_url
    except Exception as e:
        xbmc.log("[xiaoya-token] 写入 opentoken_url 失败: {}".format(str(e)), xbmc.LOGERROR)
        return open_token_url

def read_current_config():
    """读取所有配置文件的当前值"""
    token = u""
    folder_id = u""
    open_token = u""
    open_token_url = u""
    
    try:
        if os.path.exists(TOKEN_PATH):
            with open(TOKEN_PATH, 'r') as f:
                token = f.read().strip()
    except:
        pass
    
    try:
        if os.path.exists(FOLDER_PATH):
            with open(FOLDER_PATH, 'r') as f:
                folder_id = f.read().strip()
    except:
        pass
    
    try:
        if os.path.exists(OPEN_TOKEN_PATH):
            with open(OPEN_TOKEN_PATH, 'r') as f:
                open_token = f.read().strip()
    except:
        pass
    
    try:
        if os.path.exists(OPEN_TOKEN_URL_PATH):
            with open(OPEN_TOKEN_URL_PATH, 'r') as f:
                open_token_url = f.read().strip()
    except:
        pass
    
    return token, folder_id, open_token, open_token_url

def write_config(filepath, content):
    """通用写入配置文件函数"""
    try:
        if content is None:
            content = u""
        content = clean_token(content)
        
        if not content:
            xbmc.log("[xiaoya-token] 写入内容为空: {}".format(os.path.basename(filepath)), xbmc.LOGWARNING)
            return False
        
        dirpath = os.path.dirname(filepath)
        if not os.path.exists(dirpath):
            os.makedirs(dirpath)
        
        with open(filepath, 'w') as f:
            f.write(content.encode('utf-8'))
            f.write('\n')
        
        os.chmod(filepath, 0644)
        
        xbmc.log("[xiaoya-token] 文件写入成功: {} (长度: {})".format(
            os.path.basename(filepath), len(content)), xbmc.LOGINFO)
        return True
    except Exception as e:
        xbmc.log("[xiaoya-token] 写入文件失败 {}: {}".format(filepath, str(e)), xbmc.LOGERROR)
        return False

def delete_file(path):
    try:
        if os.path.exists(path):
            os.remove(path)
            return True
    except:
        pass
    return False

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip.strip()
    except:
        return '无法获取IP，请检查网络'

class TokenHandler(BaseHTTPServer.BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def do_GET(self):
        try:
            current_open_token_url = ensure_opentoken_url()
            
            parsed = urlparse(self.path)
            query = parse_qs(parsed.query)
            
            if 'clear' in query:
                clear_type = query['clear'][0]
                msg = u''
                if clear_type == 'token':
                    msg = u'✅ Token 已清空' if delete_file(TOKEN_PATH) else u'⚠️ Token 清空失败'
                elif clear_type == 'folder':
                    msg = u'✅ 文件夹ID 已清空' if delete_file(FOLDER_PATH) else u'⚠️ 文件夹ID 清空失败'
                elif clear_type == 'opentoken':
                    msg = u'✅ OpenToken 已清空' if delete_file(OPEN_TOKEN_PATH) else u'⚠️ OpenToken 清空失败'
                
                import urllib as urllib_parse
                encoded_msg = urllib_parse.quote(msg.encode('utf-8'))
                self.send_response(302)
                self.send_header('Location', '/?msg=' + encoded_msg)
                self.end_headers()
                return
            
            msg = u''
            if 'msg' in query:
                msg_raw = query['msg'][0]
                try:
                    msg = urllib.unquote(msg_raw).decode('utf-8')
                except:
                    msg = u''
            
            current_ip = get_local_ip()
            if current_ip == '无法获取IP，请检查网络':
                current_ip = '192.168.1.xxx'
            
            current_ip = current_ip.strip()
            xbmc.log("[xiaoya-token] 当前IP: {}".format(current_ip), xbmc.LOGINFO)
            
            open_token_get_url = u"http://{}:5245/".format(current_ip)
            open_token_url_value = u"http://{}:5245/api/oauth/alipan/token".format(current_ip)
            
            current_token, current_folder, current_open_token, current_open_token_url = read_current_config()
            
            token_status = u'✅ 已保存' if current_token else u'⚠️ 未设置'
            open_token_status = u'✅ 已保存' if current_open_token else u'⚠️ 未设置'
            folder_status = u'✅ 已保存' if current_folder else u'⚠️ 未设置'
            open_token_url_status = u'✅ 已生成' if current_open_token_url else u'⚠️ 未生成'
            
            msg_html = u''
            if msg:
                if u'成功' in msg or u'已保存' in msg:
                    msg_html = u'<div class="msg msg-success">{}</div>'.format(msg)
                elif u'错误' in msg or u'失败' in msg or u'无效' in msg:
                    msg_html = u'<div class="msg msg-error">{}</div>'.format(msg)
                else:
                    msg_html = u'<div class="msg msg-info">{}</div>'.format(msg)
            
            if current_folder:
                folder_readonly = u'readonly style="background:#f5f5f5;color:#555;cursor:default;"'
                edit_style = u'display:inline-block;'
                edit_btn_text = u'修改'
            else:
                folder_readonly = u''
                edit_style = u'display:none;'
                edit_btn_text = u''
            
            html_template = u"""
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>小雅配置助手</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body{font-family:sans-serif;text-align:center;padding:20px;background:#f0f2f5;}
.box{max-width:560px;margin:20px auto;background:#fff;padding:30px;border-radius:12px;box-shadow:0 2px 10px rgba(0,0,0,0.1);}
h2{color:#1a73e8;margin-top:0;font-size:22px;}
.desc{color:#666;font-size:14px;margin:-5px 0 15px 0;}
.section{border:1px solid #e0e0e0;border-radius:8px;padding:18px;margin:12px 0;background:#fafafa;text-align:left;}
.section-title{font-weight:bold;font-size:14px;color:#333;margin-bottom:4px;}
.section-desc{font-size:12px;color:#888;margin-bottom:8px;}
.section-desc a{color:#1a73e8;text-decoration:none;}
.section-desc a:hover{text-decoration:underline;}
.section input{width:100%;padding:10px;margin:6px 0 10px 0;border:1px solid #ccc;border-radius:4px;font-size:14px;box-sizing:border-box;}
.btn-row{display:flex;gap:10px;flex-wrap:wrap;}
.btn-submit{background:#4CAF50;color:#fff;border:none;padding:8px 24px;border-radius:4px;font-size:14px;cursor:pointer;}
.btn-submit:hover{background:#388E3C;}
.btn-clear{background:#ff9800;color:#fff;border:none;padding:8px 24px;border-radius:4px;font-size:14px;cursor:pointer;}
.btn-clear:hover{background:#F57C00;}
.btn-edit{background:#1a73e8;color:#fff;border:none;padding:8px 20px;border-radius:4px;font-size:14px;cursor:pointer;}
.btn-edit:hover{background:#1557b0;}
.btn-confirm{background:#1a73e8;color:#fff;border:none;padding:14px 40px;border-radius:6px;font-size:18px;cursor:pointer;width:100%;margin-top:10px;}
.btn-confirm:hover{background:#1557b0;}
.status{font-size:12px;color:#888;margin-top:8px;}
.msg{padding:12px;margin:10px 0;border-radius:4px;font-size:14px;text-align:center;}
.msg-success{background:#d4edda;color:#155724;border:1px solid #c3e6cb;}
.msg-error{background:#f8d7da;color:#721c24;border:1px solid #f5c6cb;}
.msg-info{background:#d1ecf1;color:#0c5460;border:1px solid #bee5eb;}
.note{color:#999;font-size:12px;margin-top:15px;text-align:center;}
</style>
<script>
function toggleFolderEdit() {{
    var input = document.getElementById('folder_input');
    var editBtn = document.getElementById('folder_edit_btn');
    var status = document.getElementById('folder_status');
    if (input.hasAttribute('readonly')) {{
        input.removeAttribute('readonly');
        input.style.background = '#ffffff';
        input.style.color = '#000000';
        input.style.cursor = 'text';
        editBtn.textContent = '锁定';
        editBtn.style.background = '#dc3545';
        status.innerHTML = '✏️ 编辑中...';
    }} else {{
        input.setAttribute('readonly', 'readonly');
        input.style.background = '#f5f5f5';
        input.style.color = '#555';
        input.style.cursor = 'default';
        editBtn.textContent = '修改';
        editBtn.style.background = '#1a73e8';
        status.innerHTML = '{folder_status}';
    }}
}}
</script>
</head>
<body>
<div class="box">
<h2>🔑 小雅配置助手</h2>
<p class="desc">所有已保存配置已自动加载，修改后点击「提交」即可</p>
{msg_html}

<form method="POST" action="/" style="margin:0;">

<div class="section">
<div class="section-title">📌 Token（32位）</div>
<div class="section-desc">
    <a href="https://alistgo.com/zh/guide/drivers/aliyundrive.html" target="_blank">🔗 获取Token</a>
</div>
<input type="text" name="token" placeholder="例如: 5dcaf937..." value="{token_val}">
<div class="btn-row">
<button type="submit" name="action" value="token" class="btn-submit">保存Token</button>
<button type="button" class="btn-clear" onclick="location.href='/?clear=token'">清空</button>
</div>
<div class="status">{token_status}</div>
</div>

<div class="section">
<div class="section-title">🔑 OpenToken</div>
<div class="section-desc">
    <a href="{open_token_get_url}" target="_blank">🔗 获取OpenToken</a>
    <span style="color:#999;font-size:11px;">（打开小雅Alist页面获取）</span>
</div>
<input type="text" name="open_token" placeholder="例如: 288~335位字符..." value="{open_token_val}">
<div class="btn-row">
<button type="submit" name="action" value="opentoken" class="btn-submit">保存OpenToken</button>
<button type="button" class="btn-clear" onclick="location.href='/?clear=opentoken'">清空</button>
</div>
<div class="status">{open_token_status}</div>
</div>

<div class="section" style="background:#e8f0fe;">
<div class="section-title">🌐 OpenToken URL（自动生成）</div>
<div class="section-desc">
    <span style="color:#666;">随设备IP动态生成，用于刷新OpenToken</span>
</div>
<input type="text" value="{open_token_url_val}" readonly style="background:#f5f5f5;color:#555;cursor:default;">
<div class="status">{open_token_url_status}</div>
</div>

<div class="section">
<div class="section-title">📁 文件夹ID</div>
<div class="section-desc">
    <a href="https://www.alipan.com/" target="_blank">🔗 登录阿里云盘获取</a>
    <span style="color:#999;font-size:11px;">（进入目标文件夹，复制URL末尾的ID）</span>
    <span style="color:#1a73e8;font-size:11px;font-weight:bold;">（一般不变，默认只读）</span>
</div>
<div style="display:flex;gap:8px;align-items:center;margin:6px 0 10px 0;">
    <input id="folder_input" type="text" name="folder_id" placeholder="例如: 5fe01e18..." value="{folder_val}" {folder_readonly}>
    <button id="folder_edit_btn" type="button" class="btn-edit" onclick="toggleFolderEdit()" style="{edit_style}">
        {edit_btn_text}
    </button>
</div>
<div class="btn-row">
<button type="submit" name="action" value="folder" class="btn-submit">保存文件夹ID</button>
<button type="button" class="btn-clear" onclick="location.href='/?clear=folder'">清空</button>
</div>
<div id="folder_status" class="status">{folder_status}</div>
</div>

<button type="submit" name="action" value="confirm" class="btn-confirm">提交</button>

</form>

<div class="note">💡 点击「提交」后，KODI端会停止等待并保存所有已填配置</div>
</div>
</body>
</html>"""
            
            html = html_template.replace('{msg_html}', msg_html)
            html = html.replace('{token_val}', current_token)
            html = html.replace('{token_status}', token_status)
            html = html.replace('{open_token_val}', current_open_token)
            html = html.replace('{open_token_status}', open_token_status)
            html = html.replace('{open_token_get_url}', open_token_get_url)
            html = html.replace('{open_token_url_val}', open_token_url_value)
            html = html.replace('{open_token_url_status}', open_token_url_status)
            html = html.replace('{folder_val}', current_folder)
            html = html.replace('{folder_status}', folder_status)
            html = html.replace('{folder_readonly}', folder_readonly)
            html = html.replace('{edit_btn_text}', edit_btn_text)
            html = html.replace('{edit_style}', edit_style)
            
            self.send_response(200)
            self.send_header('Content-type', 'text/html; charset=utf-8')
            self.end_headers()
            self.wfile.write(html.encode('utf-8'))
        
        except Exception as e:
            xbmc.log("[xiaoya-token] do_GET 异常: {}".format(str(e)), xbmc.LOGERROR)
            self.send_response(500)
            self.end_headers()
            self.wfile.write("服务器内部错误".encode('utf-8'))

    def do_POST(self):
        global received_token, received_folder_id, received_open_token, server_stop_flag
        
        try:
            content_len = int(self.headers.getheader('content-length', 0))
            post_data = self.rfile.read(content_len)
            params = urllib.unquote_plus(post_data)
            
            action = None
            token = None
            folder_id = None
            open_token = None
            
            for pair in params.split('&'):
                if '=' in pair:
                    key, value = pair.split('=', 1)
                    if key == 'action':
                        action = value.strip()
                    elif key == 'token':
                        token = value.strip().decode('utf-8')
                    elif key == 'folder_id':
                        folder_id = value.strip().decode('utf-8')
                    elif key == 'open_token':
                        open_token = value.strip().decode('utf-8')
            
            xbmc.log("[xiaoya-token] POST: action={}".format(action), xbmc.LOGINFO)
            
            if action == 'token':
                if token:
                    token = token.strip()
                    original_len = len(token)
                    token = clean_token(token)
                    cleaned_len = len(token)
                    xbmc.log("[xiaoya-token] Token原始长度: {}, 清洗后长度: {}".format(original_len, cleaned_len), xbmc.LOGINFO)
                    
                if token and len(token) == 32:
                    if write_config(TOKEN_PATH, token):
                        msg = u'✅ Token 已保存'
                    else:
                        msg = u'❌ Token 保存失败'
                else:
                    msg = u'❌ Token 无效，需要32位字符，当前长度: {}'.format(len(token) if token else 0)
                import urllib as urllib_parse
                self.send_response(302)
                self.send_header('Location', '/?msg=' + urllib_parse.quote(msg.encode('utf-8')))
                self.end_headers()
                return
            
            elif action == 'folder':
                if folder_id:
                    folder_id = folder_id.strip()
                if folder_id and len(folder_id) > 0:
                    if write_config(FOLDER_PATH, folder_id):
                        msg = u'✅ 文件夹ID 已保存'
                    else:
                        msg = u'❌ 文件夹ID 保存失败'
                else:
                    msg = u'❌ 文件夹ID 不能为空'
                import urllib as urllib_parse
                self.send_response(302)
                self.send_header('Location', '/?msg=' + urllib_parse.quote(msg.encode('utf-8')))
                self.end_headers()
                return
            
            elif action == 'opentoken':
                if open_token:
                    open_token = open_token.strip()
                    original_len = len(open_token)
                    open_token = clean_token(open_token)
                    cleaned_len = len(open_token)
                    xbmc.log("[xiaoya-token] OpenToken原始长度: {}, 清洗后长度: {}".format(original_len, cleaned_len), xbmc.LOGINFO)
                    
                if open_token and len(open_token) > 0:
                    if write_config(OPEN_TOKEN_PATH, open_token):
                        ensure_opentoken_url()
                        msg = u'✅ OpenToken 已保存'
                    else:
                        msg = u'❌ OpenToken 保存失败'
                else:
                    msg = u'❌ OpenToken 不能为空'
                import urllib as urllib_parse
                self.send_response(302)
                self.send_header('Location', '/?msg=' + urllib_parse.quote(msg.encode('utf-8')))
                self.end_headers()
                return
            
            elif action == 'confirm':
                has_data = False
                
                if token:
                    token = clean_token(token.strip())
                if folder_id:
                    folder_id = folder_id.strip()
                if open_token:
                    open_token = clean_token(open_token.strip())
                
                if token and len(token) == 32:
                    received_token = token
                    has_data = True
                if folder_id and len(folder_id) > 0:
                    received_folder_id = folder_id
                    has_data = True
                if open_token and len(open_token) > 0:
                    received_open_token = open_token
                    has_data = True
                
                if has_data:
                    server_stop_flag = True
                    xbmc.log("[xiaoya-token] 提交触发停止", xbmc.LOGINFO)
                    html = u"""
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>成功</title>
<style>body{font-family:sans-serif;text-align:center;padding:50px;background:#f0f2f5;}
.box{max-width:400px;margin:0 auto;background:#fff;padding:30px;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,0.1);}
h2{color:#1a73e8;} .success{color:#28a745;font-size:20px;}
</style>
</head>
<body>
<div class="box">
<h2>🎉 配置已提交</h2>
<p class="success">提交成功！</p>
<p>KODI端已收到数据，正在保存...</p>
<p style="font-size:14px;color:#888;">请返回Kodi查看结果</p>
</div>
</body>
</html>"""
                else:
                    html = u"""
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>提示</title>
<style>body{font-family:sans-serif;text-align:center;padding:50px;background:#f0f2f5;}
.box{max-width:400px;margin:0 auto;background:#fff;padding:30px;border-radius:10px;box-shadow:0 2px 10px rgba(0,0,0,0.1);}
h2{color:#dc3545;} .warning{color:#ffc107;font-size:20px;}
</style>
</head>
<body>
<div class="box">
<h2>⚠️ 无有效数据</h2>
<p class="warning">请至少填写一项有效配置</p>
<a href="/">返回</a>
</div>
</body>
</html>"""
                
                self.send_response(200)
                self.send_header('Content-type', 'text/html; charset=utf-8')
                self.end_headers()
                self.wfile.write(html.encode('utf-8'))
                return
            
            else:
                import urllib as urllib_parse
                self.send_response(302)
                self.send_header('Location', '/?msg=' + urllib_parse.quote('未知操作'.encode('utf-8')))
                self.end_headers()
                return
        
        except Exception as e:
            xbmc.log("[xiaoya-token] do_POST 异常: {}".format(str(e)), xbmc.LOGERROR)
            try:
                import urllib as urllib_parse
                self.send_response(302)
                self.send_header('Location', '/?msg=' + urllib_parse.quote('操作异常'.encode('utf-8')))
                self.end_headers()
            except:
                self.send_response(200)
                self.send_header('Content-type', 'text/plain; charset=utf-8')
                self.end_headers()
                self.wfile.write("操作异常".encode('utf-8'))

def start_web_server(port=9978, timeout=999999):
    global received_token, received_folder_id, received_open_token, server_stop_flag
    received_token = None
    received_folder_id = None
    received_open_token = None
    server_stop_flag = False

    local_ip = get_local_ip()
    if local_ip and local_ip != '无法获取IP，请检查网络':
        bind_addr = local_ip
        xbmc.log("[xiaoya-token] 绑定到具体 IP: {}".format(local_ip), xbmc.LOGINFO)
    else:
        bind_addr = '0.0.0.0'
        xbmc.log("[xiaoya-token] 回退绑定到 0.0.0.0", xbmc.LOGINFO)

    try:
        server = BaseHTTPServer.HTTPServer((bind_addr, port), TokenHandler)
        server.timeout = 1
    except Exception as e:
        xbmc.log("[xiaoya-token] 启动服务器失败: {}".format(str(e)), xbmc.LOGERROR)
        return None, None, None

    xbmc.log("[xiaoya-token] Web服务启动，绑定地址: {}，端口: {}".format(bind_addr, port), xbmc.LOGINFO)

    start_time = time.time()
    while not server_stop_flag:
        server.handle_request()
        if (time.time() - start_time) > timeout:
            xbmc.log("[xiaoya-token] 服务超时（{}秒），继续等待".format(timeout), xbmc.LOGWARNING)

    server.server_close()
    xbmc.log("[xiaoya-token] Web服务已关闭", xbmc.LOGINFO)
    return received_token, received_folder_id, received_open_token