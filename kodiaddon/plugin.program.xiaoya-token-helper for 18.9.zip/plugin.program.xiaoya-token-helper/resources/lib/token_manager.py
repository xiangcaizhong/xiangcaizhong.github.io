# -*- coding: utf-8 -*-
import os
import xbmc

class TokenManager:
    def read_token(self, filepath):
        try:
            if os.path.exists(filepath):
                with open(filepath, 'r') as f:
                    return f.read().strip()
        except Exception as e:
            xbmc.log("[xiaoya-token] 读Token失败: {}".format(str(e)), xbmc.LOGERROR)
        return None

    def write_token(self, filepath, token):
        try:
            dirpath = os.path.dirname(filepath)
            if not os.path.exists(dirpath):
                os.makedirs(dirpath, 0755)
            with open(filepath, 'w') as f:
                f.write(token.strip())
            os.chmod(filepath, 0644)
            return True
        except Exception as e:
            xbmc.log("[xiaoya-token] 写Token失败: {}".format(str(e)), xbmc.LOGERROR)
            return False

    def clear_token(self, filepath):
        try:
            if os.path.exists(filepath):
                os.remove(filepath)
                return True
        except:
            pass
        return False