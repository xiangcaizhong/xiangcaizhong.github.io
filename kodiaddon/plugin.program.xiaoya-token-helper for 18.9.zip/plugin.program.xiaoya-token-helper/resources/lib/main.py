# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcaddon
import threading
import time
import web_receiver
from token_manager import TokenManager
import os

class Main:
    def __init__(self, addon):
        xbmc.log("[xiaoya-token] Main.__init__ start", xbmc.LOGINFO)
        self.addon = addon
        self.token_mgr = TokenManager()
        self.token_path = "/storage/xiaoya/mytoken.txt"
        self.folder_id_path = "/storage/xiaoya/temp_transfer_folder_id.txt"
        self.open_token_path = "/storage/xiaoya/myopentoken.txt"
        self.current_token = ""
        self.current_folder_id = ""
        self.current_open_token = ""
        xbmc.log("[xiaoya-token] Main.__init__ done", xbmc.LOGINFO)

    def run(self):
        xbmc.log("[xiaoya-token] Main.run start", xbmc.LOGINFO)
        try:
            self.current_token = self.token_mgr.read_token(self.token_path)
            self.current_folder_id = self.token_mgr.read_token(self.folder_id_path)
            self.current_open_token = self.token_mgr.read_token(self.open_token_path)
            xbmc.log("[xiaoya-token] Token: {}".format(self.current_token), xbmc.LOGINFO)
            xbmc.log("[xiaoya-token] FolderID: {}".format(self.current_folder_id), xbmc.LOGINFO)
            xbmc.log("[xiaoya-token] OpenToken: {}".format(self.current_open_token), xbmc.LOGINFO)
        except Exception as e:
            xbmc.log("[xiaoya-token] read error: {}".format(str(e)), xbmc.LOGERROR)
        self.show_main_menu()
        xbmc.log("[xiaoya-token] Main.run done", xbmc.LOGINFO)

    def show_main_menu(self):
        xbmc.log("[xiaoya-token] show_main_menu start", xbmc.LOGINFO)
        dialog = xbmcgui.Dialog()
        
        try:
            local_ip = web_receiver.get_local_ip()
        except:
            local_ip = "No IP"

        option1 = u"启动网页服务并提交配置  (IP: {})".format(local_ip)
        option2 = u"检测所有配置有效性"
        option3 = u"重启小雅服务"

        options = [
            (option1, self.start_web_and_wait),
            (option2, self.show_status),
            (option3, self.restart_xiaoya),
        ]

        try:
            selected = dialog.select(u"小雅Token配置助手", [opt[0] for opt in options])
            if selected >= 0:
                options[selected][1]()
        except Exception as e:
            xbmc.log("[xiaoya-token] menu error: {}".format(str(e)), xbmc.LOGERROR)
            dialog.ok(u"错误", u"菜单操作异常:\n{}".format(str(e)))

    def start_web_and_wait(self):
        xbmc.log("[xiaoya-token] start_web_and_wait start", xbmc.LOGINFO)
        dialog = xbmcgui.Dialog()
        
        web_receiver.received_token = None
        web_receiver.received_folder_id = None
        web_receiver.received_open_token = None
        web_receiver.server_stop_flag = False
        
        try:
            local_ip = web_receiver.get_local_ip()
            port = 9978
            web_url = "http://{}:{}".format(local_ip, port)
        except Exception as e:
            xbmc.log("[xiaoya-token] get IP error: {}".format(str(e)), xbmc.LOGERROR)
            dialog.ok(u"错误", u"无法获取本机IP，请检查网络")
            return

        xbmc.log("[xiaoya-token] starting web server...", xbmc.LOGINFO)
        
        def run_server():
            token, folder, open_token = web_receiver.start_web_server(port=port, timeout=999999)
            xbmc.log("[xiaoya-token] server done", xbmc.LOGINFO)

        thread = threading.Thread(target=run_server)
        thread.daemon = True
        thread.start()

        progress = xbmcgui.DialogProgress()
        progress.create(u"等待提交",
                        u"",
                        u"手机浏览器访问：",
                        u"{}".format(web_url))
        
        data_received = False
        
        while not progress.iscanceled():
            if (web_receiver.received_token is not None or 
                web_receiver.received_folder_id is not None or 
                web_receiver.received_open_token is not None):
                data_received = True
                xbmc.log("[xiaoya-token] data received", xbmc.LOGINFO)
                break
            xbmc.sleep(100)
        
        progress.close()
        
        if data_received:
            xbmc.log("[xiaoya-token] processing data", xbmc.LOGINFO)
            web_receiver.server_stop_flag = True
            xbmc.sleep(300)
            self.save_config(web_receiver.received_token, 
                           web_receiver.received_folder_id,
                           web_receiver.received_open_token)
        else:
            xbmc.log("[xiaoya-token] user cancel", xbmc.LOGINFO)
            web_receiver.server_stop_flag = True
            dialog.ok(u"已取消", u"操作已取消")

        xbmc.log("[xiaoya-token] start_web_and_wait done", xbmc.LOGINFO)

    def save_config(self, token, folder_id, open_token):
        dialog = xbmcgui.Dialog()
        messages = []
        success = False

        if token:
            try:
                if self.token_mgr.write_token(self.token_path, token):
                    self.current_token = token
                    messages.append(u"Token 已写入")
                    success = True
                else:
                    messages.append(u"Token 写入失败")
            except Exception as e:
                messages.append(u"Token 写入异常: {}".format(str(e)))
        else:
            messages.append(u"Token 未修改")

        if folder_id:
            try:
                if self.token_mgr.write_token(self.folder_id_path, folder_id):
                    self.current_folder_id = folder_id
                    messages.append(u"文件夹ID 已写入")
                    success = True
                else:
                    messages.append(u"文件夹ID 写入失败")
            except Exception as e:
                messages.append(u"文件夹ID 写入异常: {}".format(str(e)))
        else:
            messages.append(u"文件夹ID 未修改")

        if open_token:
            try:
                if self.token_mgr.write_token(self.open_token_path, open_token):
                    self.current_open_token = open_token
                    messages.append(u"OpenToken 已写入")
                    success = True
                else:
                    messages.append(u"OpenToken 写入失败")
            except Exception as e:
                messages.append(u"OpenToken 写入异常: {}".format(str(e)))
        else:
            messages.append(u"OpenToken 未修改")

        if success:
            dialog.ok(u"配置保存成功", u"\n".join(messages))
        else:
            if token is None and folder_id is None and open_token is None:
                dialog.ok(u"未提交新配置", u"请先提交配置，再点击总确认")
            else:
                dialog.ok(u"保存失败", u"\n".join(messages))

    def show_status(self):
        xbmc.log("[xiaoya-token] show_status start", xbmc.LOGINFO)
        dialog = xbmcgui.Dialog()
        
        token_status = "Unknown"
        open_status = "Unknown"
        folder_status = "Unknown"
        status_115 = "Unknown"
        
        try:
            import subprocess
            
            container_name = "xiaoya"
            
            result = subprocess.Popen(
                ["docker", "logs", container_name],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT
            )
            
            stdout, _ = result.communicate()
            raw_data = stdout
            
            if not raw_data:
                xbmc.log("[xiaoya-token] log empty", xbmc.LOGWARNING)
                token_status = "Log empty"
                open_status = "Log empty"
                folder_status = "Log empty"
                status_115 = "Log empty"
            else:
                raw_lower = raw_data.lower()
                
                refresh_token = b"refresh token"
                token_invalid = b"invalid"
                
                # Check Aliyun Token
                if b"failed to refresh token" in raw_lower and b"empty" in raw_lower:
                    token_status = "INVALID (token empty)"
                elif refresh_token in raw_lower and b"empty" in raw_lower:
                    token_status = "Maybe invalid"
                elif token_invalid in raw_lower and refresh_token in raw_lower:
                    token_status = "Maybe invalid"
                else:
                    token_status = "OK (no error)"
                
                # Check OpenToken
                if b"open" in raw_lower and b"token" in raw_lower:
                    if token_invalid in raw_lower or b"failed" in raw_lower:
                        open_status = "Maybe invalid"
                    else:
                        open_status = "OK (no error)"
                else:
                    open_status = "No error found"
                
                # Check Folder
                if b"folder" in raw_lower or b"file_id" in raw_lower:
                    if b"not found" in raw_lower or b"failed" in raw_lower:
                        folder_status = "Maybe issue"
                    else:
                        folder_status = "Mounted"
                else:
                    folder_status = "Set"
                
                # Check 115 Token
                cookie_pattern = b"\xe6\x9c\x89\xe6\x95\x88\xe7\x9a\x84 115 Cookie"
                member_pattern = b"\xe4\xbd\xa0\xe6\x98\xaf115\xe5\xb0\x8a\xe8\xb4\xb5\xe7\x9a\x84\xe4\xbc\x9a\xe5\x91\x98"
                
                if cookie_pattern in raw_data or member_pattern in raw_data:
                    status_115 = "VALID (115 VIP)"
                elif b"115" in raw_data and b"\xe5\xa4\xb1\xe6\x95\x88" in raw_data:
                    status_115 = "INVALID (expired)"
                elif b"115" in raw_data and b"\xe8\xbf\x87\xe6\x9c\x9f" in raw_data:
                    status_115 = "INVALID (expired)"
                elif b"115" in raw_data and b"\xe6\x97\xa0\xe6\x95\x88" in raw_data:
                    status_115 = "INVALID"
                elif b"115" in raw_lower and b"failed" in raw_lower:
                    status_115 = "Maybe invalid"
                elif b"115" in raw_lower and token_invalid in raw_lower:
                    status_115 = "Maybe invalid"
                else:
                    if b"115" in raw_data:
                        status_115 = "OK (no error)"
                    else:
                        status_115 = "No 115 log"
            
            xbmc.log("[xiaoya-token] 115 status: {}".format(status_115), xbmc.LOGINFO)
            
        except Exception as e:
            xbmc.log("[xiaoya-token] status error: {}".format(str(e)), xbmc.LOGERROR)
            token_status = "Error"
            open_status = "Error"
            folder_status = "Error"
            status_115 = "Error"
        
        # 只有这个窗口用英文，其他全部中文
        info = [
            "=== Config Status ===",
            "",
            "Aliyun Token: " + token_status,
            "OpenToken: " + open_status,
            "Folder ID: " + folder_status,
            "115 Token: " + status_115,
            "",
            "Note: Check Xiaoya for actual effect",
        ]
        
        dialog.ok("Status", "\n".join(info))
        xbmc.log("[xiaoya-token] show_status done", xbmc.LOGINFO)

    def restart_xiaoya(self):
        dialog = xbmcgui.Dialog()
        if dialog.yesno(u"确认重启", u"将尝试重启小雅Alist服务"):
            import subprocess
            try:
                ret = subprocess.call(["docker", "restart", "xiaoya"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                if ret != 0:
                    ret = subprocess.call(["systemctl", "restart", "xiaoya"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                if ret == 0:
                    dialog.ok(u"重启命令已执行", u"请稍后检查服务状态")
                else:
                    dialog.ok(u"重启失败", u"请手动重启小雅服务")
            except Exception as e:
                dialog.ok(u"错误", u"{}".format(str(e)))
