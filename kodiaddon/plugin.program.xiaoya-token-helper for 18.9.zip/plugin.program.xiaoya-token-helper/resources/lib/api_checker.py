# -*- coding: utf-8 -*-
import json
import urllib2
import xbmc

class AliyunTokenChecker:
    def check_token(self, token):
        if not token or len(token.strip()) != 32:
            return False
        
        token = token.strip()
        url = "https://api.aliyundrive.com/v2/user/get"
        req = urllib2.Request(url)
        req.add_header('Authorization', 'Bearer {}'.format(token))
        req.add_header('Content-Type', 'application/json')
        
        try:
            response = urllib2.urlopen(req, timeout=10)
            if response.getcode() == 200:
                data = json.loads(response.read())
                if data.get('user_id'):
                    return True
        except urllib2.HTTPError as e:
            if e.code == 401:
                xbmc.log("[xiaoya-token] Token无效(401)", xbmc.LOGWARNING)
            else:
                xbmc.log("[xiaoya-token] HTTP错误: {}".format(e.code), xbmc.LOGWARNING)
        except Exception as e:
            xbmc.log("[xiaoya-token] 校验异常: {}".format(str(e)), xbmc.LOGERROR)
        
        try:
            url2 = "https://api.aliyundrive.com/v2/file/list"
            data = json.dumps({"drive_id": "default", "parent_file_id": "root", "limit": 1})
            req2 = urllib2.Request(url2, data=data)
            req2.add_header('Authorization', 'Bearer {}'.format(token))
            req2.add_header('Content-Type', 'application/json')
            resp2 = urllib2.urlopen(req2, timeout=10)
            return resp2.getcode() == 200
        except:
            return False