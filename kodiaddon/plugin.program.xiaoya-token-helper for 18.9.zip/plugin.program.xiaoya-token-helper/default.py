# -*- coding: utf-8 -*-
import sys
import traceback
import xbmc
import xbmcgui
import xbmcaddon

addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path')
lib_path = xbmc.translatePath(addon_path + '/resources/lib')
if lib_path not in sys.path:
    sys.path.insert(0, lib_path)

try:
    xbmc.log("[xiaoya-token] default.py: 开始导入 main 模块", xbmc.LOGINFO)
    from resources.lib.main import Main
    xbmc.log("[xiaoya-token] default.py: 导入 main 成功", xbmc.LOGINFO)
except Exception as e:
    tb = traceback.format_exc()
    xbmc.log("[xiaoya-token] default.py 导入失败: {}".format(tb), xbmc.LOGERROR)
    dialog = xbmcgui.Dialog()
    dialog.ok("插件错误", "导入模块失败，请查看日志。\n错误: {}".format(str(e)))
    sys.exit(1)

if __name__ == "__main__":
    try:
        xbmc.log("[xiaoya-token] default.py: 开始运行 Main", xbmc.LOGINFO)
        main = Main(addon)
        main.run()
        xbmc.log("[xiaoya-token] default.py: Main 运行结束", xbmc.LOGINFO)
    except Exception as e:
        tb = traceback.format_exc()
        xbmc.log("[xiaoya-token] default.py 运行时错误: {}".format(tb), xbmc.LOGERROR)
        dialog = xbmcgui.Dialog()
        dialog.ok("运行时错误", "发生异常，请查看日志。\n错误: {}".format(str(e)))